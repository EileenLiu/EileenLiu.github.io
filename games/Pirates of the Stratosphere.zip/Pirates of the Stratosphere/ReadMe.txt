Click setup.exe to install.
Pirates of the Stratosphere runs best on Windows. 
For Mac support, see
http://stackoverflow.com/questions/6325003/can-xna-games-run-on-mac