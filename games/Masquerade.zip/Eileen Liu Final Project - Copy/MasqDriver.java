 	//Eileen Liu
   //June 01, 2010
   import javax.swing.*;/*(description from Java API) the JFrame Class, An extended 
	//version of java.awt.Frame that adds support for the JFC/Swing component architecture*/
   import java.io.*; //the FileNotFoundException, the File class
   import java.util.Scanner; //the PriorityQueue class, the Scanner class
   import java.awt.Dimension;/*(description from Java API) the Dimension Class, The Dimension 
   //class encapsulates the width and height of a component (in integer precision) in a single
	//object. The class is associated with certain properties of components. Several methods defined 
	//by the Component class and the LayoutManager interface return a Dimension object*/
   import java.awt.Toolkit;/*(description from Java API) the Toolkit Class, This class is the 
   //abstract superclass of all actual implementations of the Abstract Window Toolkit. Subclasses
	//of Toolkit are used to bind the various components to particular native toolkit implementations.*/

/**
 * MasqDriver runs the Masquerade program.
 * @author  Eileen Liu
 */
    public class MasqDriver
   {
       	/**
   		 * Creates and displays a JFrame with a MasqPanel as its content. 
   		 */
       public static void main(String[] args)
      {
         JFrame frame = new JFrame();//"Masquerade!");
         setFullScreen(frame);   
         frame.validate();
         frame.setLocation(0, 0);
         frame.setDefaultCloseOperation(
                       JFrame.EXIT_ON_CLOSE);
         frame.setContentPane(new MasqPanel());//sets the frame to contain a MasqPanel
         frame.setVisible(true);
         showInstructions();
      }
		
   	   /**
   		 * Sets the specified JFrame to fullscreen.
       	 * @param	frame	the JFrame to set to fullscreen 
   		 */
       private static void setFullScreen(JFrame frame)
      {
         Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
         frame.setSize(screenSize.width, screenSize.height);
      }
   	/** Displays instructions to the user. */
       private static void showInstructions()
      {
         String instructions = "Create your own character!"+
            " \nCustomize your character's hairstyle, facial features, costumes, and character information!" +
            " \n\nChange the appearance of your character using the panel of buttons on the right." +
            " \nYou may also change the color of the item you last chose using the color changer in the upper right corner" +
            " \nChange the information about your character using the character profile panel on the left."+
            " \nYou may enter character information into the form yourself"+
            " \nor you may choose from a list of character traits by pressing the buttons for each type of trait.";
         javax.swing.JOptionPane.showMessageDialog(null, instructions); //displays instructions using a joptionpane
      } 
   }