 //Eileen Liu
 //June 01, 2010
   
   import javax.swing.*; //the JPanel Class
   import java.awt.*; //the BorderLayoutClass
   import java.io.*; //the File Class, the FileNotFoundException Class
   import java.util.*;   //the Scanner class
 
    public class MasqPanel  extends JPanel //panel that holds all the secondary components
   {
      /**Displays the character and costumes.*/
      public DisplayPanel display;
   	/**Buttons that allows user to change costumes and colors.*/
      public ButtonPanel buttons;
      /**Displays and allows user to change character traits.*/
      public CharacterProfilePanel characterProfile;    
   	 /**
        * Constructs MasqPanel, a panel with BorderLayout, and adds all of the components.
        */
       public MasqPanel()
      {
         setLayout(new BorderLayout());
         createComponents();
         addComponents();
      }
      /**
   	 *  Instantiates the display, buttons, and character profile.
   	 */
       private void createComponents()
      {
         display = new DisplayPanel(this); //creates a DisplayPannel connected to this MasqPanel		
         buttons = new ButtonPanel(this); //creates a ButtonPanel connected to this MasqPanel
         characterProfile = new CharacterProfilePanel();
      }
      /**
   	 *Adds the display, buttons, and character profile to the MasqPanel.
   	 */   
       private void addComponents()
      {
         add(characterProfile, BorderLayout.WEST);
         add(display, BorderLayout.CENTER);
         add(buttons, BorderLayout.EAST);
      }
   }
