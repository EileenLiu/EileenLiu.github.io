 //Eileen Liu
   //June 01, 2010
	
   import java.awt.*;//the BorderLayout Class, the GridLayout Class, the Color Class, the Image Class
   import java.awt.event.*;//the ActionListener Class, the ActionEvent class
   import javax.swing.*;//the JPanel Class, the JComponenet Class, the JLabel Class, the JColorChooser Class
   import javax.swing.event.ChangeEvent; /*(Description from Java's API) the ChangeEvent Class, ChangeEvent 
   //is used to notify interested parties that state has changed in the event source*/
   import javax.swing.event.ChangeListener;/*(Description from Java's API) the ChangeListener Class
   //Defines an object which listens for ChangeEvents*/
   /**
 	 * ButtonPanel is class that allows the user to change the costumes and colors of costumes displayed in DisplayPanel 
	 * @author  Eileen Liu
	 * @see     javax.swing.JPanel
    */
    public class ButtonPanel extends JPanel
   {  
     /**The board of JButtons (that when pressed, change costumes) and JLabels (that display name of the costume last changed).*/
      private JComponent[][] board;
      /**The main panel containing this button panel*/
      private MasqPanel parentPanel; 
      /**The number of rows in the board*/
      private final int ROWS=12;
      /**The panel on which the board is contained**/
      private JPanel buttonPane;
      /**The interface that changes the color of the most recently selected costume*/
      private JColorChooser colorChooser;
   
   	 /**
        * Constructs ButtonPanel, a panel with borderlayout, and its components
   	  * @param     m	the MasqPanel that contains this ButtonPanel.
        */
   	
       public ButtonPanel(MasqPanel m)
      {
         parentPanel = m;
         setLayout(new BorderLayout());
         createButtonPanel();
         setLabelText();
         createColorChooser();
         addComponents(); 
      }
       /**Adds colorChooser and buttonPane to ButtonPanel*/
       private void addComponents()
      {
         add(colorChooser, BorderLayout.NORTH);
         add(buttonPane, BorderLayout.CENTER);
      }
      /**Creates a panel of buttons that changes costumes displayed in DisplayPanel*/
       private void createButtonPanel()
      {
         buttonPane = new JPanel();
         buttonPane.setLayout(new GridLayout(ROWS, 3));
              	
         board = new JComponent[ROWS][3];      	
         for(int r = 0; r < ROWS; r++)
         {
            board[r][0] = new JButton("Previous");
            ((JButton)board[r][0]).addActionListener( new Handler1(r,0));
            board[r][1] = new JLabel();
            ((JLabel)board[r][1]).setHorizontalAlignment(SwingConstants.CENTER);
            board[r][2] = new JButton("Next");
            ((JButton)board[r][2]).addActionListener( new Handler1(r,2));
            buttonPane.add(board[r][0]);
            buttonPane.add(board[r][1]);
            buttonPane.add(board[r][2]);	
         }
      }
      /**Creates an interface that changes the color of the last changed costume displayed in DisplayPanel*/
       private void createColorChooser()
      {
         colorChooser = new JColorChooser();
         colorChooser.setPreviewPanel(new JPanel()); //deletes the preview panel by replacing it with a blank JPanel
         colorChooser.getSelectionModel().addChangeListener(new ColorChangeListener()); //attaches a change listener to listen if the color selected by the user has changed
      }
      /**Labels all the labels accoriding to the type of costume their associated buttons change.*/
       private void setLabelText()
      {
         ((JLabel)board[0][1]).setText("Hair"); 
         ((JLabel)board[1][1]).setText("Eyewear");
         ((JLabel)board[2][1]).setText("Eyes");
         ((JLabel)board[3][1]).setText("Nose");
         ((JLabel)board[4][1]).setText("Mouth");
         ((JLabel)board[5][1]).setText("Accessory 1");
         ((JLabel)board[6][1]).setText("Accessory 2");
         ((JLabel)board[7][1]).setText("Top");
         ((JLabel)board[8][1]).setText("Bottom");
         ((JLabel)board[9][1]).setText("Shoes");
         ((JLabel)board[10][1]).setText("Gender");
         ((JLabel)board[11][1]).setText("Background");  
      }
     /**
   	* Sets the text of the label in the specified row to the specified text.
   	* @param     r		the row of the label to be updated
   	* @param     s		the String the label is updated to
      */
       public void updateCostumeLabel(int r, String s)
      {
         ((JLabel)board[r][1]).setText(s);
      }
   /**
    * ColorChangeListener listens for ChangeEvents and changes the color of the 
    * last changed costume displayed in the Display Panel when a ChangeEvent occurs. 
    * @see     javax.swing.event.ChangeListener
    */
       private class ColorChangeListener implements ChangeListener
      {      
      	 /**Changes color of the last changed costume displayed in the DisplayPanel when a ChangeEvent occurs.*/
          public void stateChanged(ChangeEvent e) 
         {
            Color newColor = colorChooser.getColor(); //stores the color selected by the user
            parentPanel.display.changeColor(newColor, parentPanel.display.lastChanged); //tells parentPanel's display
            //to change the color of the costume that was last changed to the new color
         }
      }
     /**
     * Handler1 listens for ActionEvents and changes a costume displayed in DisplayPanel when an ActionEvent occurs.
     * @see		java.awt.event.ActionListener
     */	
       private class Handler1 implements ActionListener
      {
         public int myRow, myCol;
        
        /**
        * Constructs a Handler in the specified row and column
        * @param     r	the row the Handler1 is located..
        * @param     c	the colunm the Handler1 is located.
        */
          public Handler1(int r, int c)
         {
            myRow = r;
            myCol = c;
         }
      	/**Changes a costume displayed in DisplayPanel based on the row and column the ActionListener is located*/      
          public void actionPerformed(ActionEvent e)
         {
            parentPanel.display.changeCostume(myRow,myCol);
         }
      } 	
      	
   }
