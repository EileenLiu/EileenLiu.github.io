 //APCS DATA STRUCTURES are used in this class (TreeNode)
  
  //Eileen Liu
  //June 01, 2010
  
   import java.awt.*; //the Gridlayout Class, the BorderLayout Class
   import java.awt.event.*; //the ActionListener Class, the ActionEvent Class
   import javax.swing.*; //the JPanel Class, the JComponent Class, the JButton Class, the JLabel Class, the JTextField
   import java.io.*; //the File Class, the FileNotFoundException Class
   import java.util.*;   //the Scanner class
    /**
 	 * CharacterProfilePanel is a class that displays and allows the user to change character traits. 
	 * Note: Although these traits describe the character displayed on DisplayPanel,
	 * this class only changes traits displayed on itself, not what is displayed on DisplayPanel
	 * @author  Eileen Liu
	 * @see     javax.swing.JPanel
    */
    public class CharacterProfilePanel extends JPanel
   {
      /**the board of JLabels, JTextFields, and associated JButtons*/
      public JComponent[][] board; 
   	/**the number of rows in the board*/
      private final int ROWS=8; 
      public TreeNode myAge; //age of the character
      public TreeNode myElement; //element of the character
      public TreeNode myPersonality; //personality trait of the character
      public TreeNode myRace; //race of the character
      public TreeNode myClass; //class of the character
      public TreeNode myWeapon; //weapon of the character
      public TreeNode myPowerOne; //primary power/ability of the character
      public TreeNode myPowerTwo; //secondary power/ability of the character
   	
   	 /**
        * Constructs CharacterProfilePanel, a panel with gridlayout, and its components
        */
       public CharacterProfilePanel()
      {
         setLayout(new GridLayout(ROWS*2+2, 1, 3, 3)); 
      	//sets the CharacterProfilePanel's layout to a gridlayout with ROWS*2+2 rows, one column, vertical and horizontal gap of 3
         createNameSpace();     	
         board = new JComponent[ROWS][4]; //creates board as a matrix of JComponents with ROWS rows and 4 colunms
         createBoard();      	
         setLabels();
         createTraitLists();
      }
      /**
   	* Creates all of the circular doubly linked lists of traits by calling method createTraitListHelper for each type of trait.
   	* @see	#createTraitListHelper(String)
   	*/
       private void createTraitLists()
      {
         try 
         {      
            myElement = createTraitListHelper("ElementList.txt");
            myRace = createTraitListHelper("RaceList.txt");        
            myPersonality = createTraitListHelper("PersonalitiesList.txt");
            myClass=createTraitListHelper("ClassList.txt");
            myWeapon=createTraitListHelper("WeaponsList.txt");
            myPowerOne=createTraitListHelper("PowersList.txt");      
            myPowerTwo=createTraitListHelper("PowersList.txt");
         }
             catch(FileNotFoundException e)
            {
               System.out.println("One or more files were not found");
               System.exit(0);
            }
      }
      /**
   	* Creates a circular doubly linked list of traits (constructed out of TreeNodes) from the specified textfile.
   	* @param textfile		a textfile containing strings of character traits from which the traitlist is created
   	* @return     the first trait in a circular doubly linked list of traits (constructed out of TreeNodes).
   	* @see	TreeNode
   	*/
       private TreeNode createTraitListHelper(String textfile)throws FileNotFoundException
      {
         Scanner infile = new Scanner(new File(textfile)); //creates a scanner that reads from the textfile
         TreeNode head=null;
			//creates the first character trait in the list
         if(infile.hasNext())
         {
            head=new TreeNode(infile.nextLine()); //stores the trait read by the scanner as the first in the list
         } 
         TreeNode current = head;
			//Links each trait into a DOUBLY LINKED LIST
         while(infile.hasNextLine())
         {
            TreeNode cn=new TreeNode(infile.nextLine()); //stores trait read by scanner as the next in the list
            current.setRight(cn); //links current trait to next one in list
            cn.setLeft(current); //links next trait with current
            current=current.getRight(); //updates which trait is the current one, continues down the list
         }
			//links the back of the list to the front (makes it a CIRCULAR LINKED LIST)
         if(head!=null&&!head.equals(current))//checks if the list isn't empty or with only one trait
         {
            head.setLeft(current); //links first trait to last
            current.setRight(head); //links last trait to first
         }
         return head; //returns the first trait in the circular doubly linked list
      }
   
      /**
   	* Creates JComponent board by calling methods createTextSpace and createButtonSpace for each row.
   	*/
       private void createBoard()
      {
         for(int r = 0; r < ROWS; r++)
         {
            createTextSpace(r);
            createButtonSpace(r);
         }
      }
      /**
   	 * Creates a previous and a next button (that when pressed, change the traits 
   	 * displayed in the textspace they're associated with) at the specified row.
   	 * @param r		the row the buttonspace is to be created 
       */
       private void createButtonSpace(int r)
      {
         board[r][2] = new JButton("Previous");
         ((JButton)board[r][2]).addActionListener( new Handler1(r,2));
          
         board[r][3] = new JButton("Next");
         ((JButton)board[r][3]).addActionListener( new Handler1(r,3));
          
         JPanel buttonspace = new JPanel(); //creates JPanel to hold the two buttons
         buttonspace.setLayout(new GridLayout(1, 2)); //GridLayout to make buttons the same size
         buttonspace.add(board[r][2]);
         buttonspace.add(board[r][3]);
         add(buttonspace);
      }
      /**Sets the appropriate text for JLabels, JTextFields, and a few JButtons on the JComponent board.*/
       private void setLabels()
      {
         //Labels labels depending on the type of trait their associated textfields display
         ((JLabel)board[0][0]).setText("  Age: "); 
         ((JLabel)board[1][0]).setText("  Element: ");
         ((JLabel)board[2][0]).setText("  Personality: ");
         ((JLabel)board[3][0]).setText("  Race: ");
         ((JLabel)board[4][0]).setText("  Class: ");
         ((JLabel)board[5][0]).setText("  Weapon: ");
         ((JLabel)board[6][0]).setText("  Power 1: ");
         ((JLabel)board[7][0]).setText("  Power 2: ");
         //adds small instructions for the user in the textfields
         ((JTextField)board[0][1]).setText("Enter age"); 
         ((JTextField)board[1][1]).setText("Enter element or press buttons below");
         ((JTextField)board[2][1]).setText("Enter personality or press buttons below");
         ((JTextField)board[3][1]).setText("Enter race or press buttons below");
         ((JTextField)board[4][1]).setText("Enter class or press buttons below");
         ((JTextField)board[5][1]).setText("Enter weapon or press buttons below");
         ((JTextField)board[6][1]).setText("Enter power or press buttons below");
         ((JTextField)board[7][1]).setText("Enter secondary power or press buttons below");
      	//These buttons change the Age character trait, so they have special labels
         ((JButton)board[0][2]).setText("Decrement");
         ((JButton)board[0][3]).setText("Increment");
      }
      /**Creates a space for the user to name their character in.*/
       private void createNameSpace()
      {
         //adds instructions about the CharacterProfilePanel for the user at the top
         add(new JLabel("  Select from a list of character traits, or type in your own!"));
         JPanel namespace = new JPanel(); //creates JPanel to hold label and textfield
         namespace.setLayout(new BorderLayout()); //BorderLayout so label and textfield don't have to be same size
         namespace.add(new JLabel("  Name:", SwingConstants.LEFT), BorderLayout.WEST);
         namespace.add(new JTextField("Enter Character Name", 20), BorderLayout.CENTER); //creates textfield with small instructions for user
         add(namespace);
      }
      /**
   	 * Creates a label for a type of trait and a textfield that displays a trait of that type in the specified row.
     	 * @param r		the row the textspace is to be created 
   	 */
       private void createTextSpace(int r)
      {
         board[r][0] = new JLabel("", SwingConstants.RIGHT);
         board[r][1]= new JTextField("", 10);
         JPanel textspace = new JPanel();
         textspace.setLayout(new BorderLayout()); //borderlayout so label and textfield dont' have to be same size
         textspace.add(board[r][0], BorderLayout.WEST);
         textspace.add(board[r][1], BorderLayout.CENTER);
         add(textspace);
      }
      /**
     * Handler1 listens for ActionEvents and changes a trait displayed when an ActionEvent occurs.
     * @see		java.awt.event.ActionListener
     */	
       private class Handler1 implements ActionListener
      {
         public int myRow, myCol;
         
       /**
        * Constructs a Handler in the specified row and column
        * @param     r	the row the Handler1 is located..
        * @param     c	the colunm the Handler1 is located.
        */
          public Handler1(int r, int c)
         {
            myRow = r; //row of associated button
            myCol = c; //column of associated button
         }
         /**Changes a trait displayed on CharacterProfilePanel based on the row and column the ActionListener is located.*/
          public void actionPerformed(ActionEvent e)
         {
            String s=""; //the trait to be displayed
            if(myRow==0)//button pressed must change myAge
            {
               try 
               {      
                  int age = Integer.parseInt(((JTextField)board[0][1]).getText()); //converts string from textfield into an integer
                  if(myCol==2)
                     s=""+(age-1); //decrements
                  else
                     s=""+(age+1); //increments
               }
                   catch(NumberFormatException k)//the string could not be converted
                  {
                     s=""+0; //the age resets to 0
                  }
            }
            if(myRow ==1)//button pressed must change myElement
            {
               if(myCol ==2) //the previous button was pressed
                  myElement=myElement.getLeft();
               else //myCol must equal 3, meaning the next button was pressed
                  myElement=myElement.getRight();
               s=(String)myElement.getValue();	
            }
            else if(myRow ==2)//button pressed must change myPersonality
            {
               if(myCol ==2)//the previous button was pressed
                  myPersonality=myPersonality.getLeft();
               else//myCol must equal 3, meaning the next button was pressed
                  myPersonality=myPersonality.getRight();
               s=(String)myPersonality.getValue();
            }
            else if(myRow ==3)//button pressed must change myRace
            {
               if(myCol ==2)//the previous button was pressed
                  myRace=myRace.getLeft();
               else//myCol must equal 3, meaning the next button was pressed
                  myRace=myRace.getRight();
               s=(String)myRace.getValue();
            
            }
            else if(myRow ==4)//button pressed must change myClass
            {
               if(myCol ==2)//the previous button was pressed
                  myClass=myClass.getLeft();
               else//myCol must equal 3, meaning the next button was pressed
                  myClass=myClass.getRight();
               s=(String)myClass.getValue();
            
            }	
            else if(myRow ==5)//button pressed must change myWeapon
            {
               if(myCol ==2)//the previous button was pressed
                  myWeapon=myWeapon.getLeft();
               else//myCol must equal 3, meaning the next button was pressed
                  myWeapon=myWeapon.getRight();
               s=(String)myWeapon.getValue();
            }              	
            else if(myRow ==6)//button pressed must change myPowerOne
            {
               if(myCol ==2)//the previous button was pressed
                  myPowerOne=myPowerOne.getLeft();
               else//myCol must equal 3, meaning the next button was pressed
                  myPowerOne=myPowerOne.getRight();
               s=(String)myPowerOne.getValue();         	
            }
            else if(myRow ==7)//button pressed must change myPowerTwo
            {
               if(myCol ==2)//the previous button was pressed
                  myPowerTwo=myPowerTwo.getLeft();
               else//myCol must equal 3, meaning the next button was pressed
                  myPowerTwo=myPowerTwo.getRight();
               s=(String)myPowerTwo.getValue();         	
            }
            ((JTextField)board[myRow][1]).setText(s); //changes the trait displayed in the textfield
         }
      	
      } 	
      	
   }
