//This class is an APCS DATA STRUCTURE (list node used to create circular doubly linked lists)
 //(has a priority so it may be put in priority queues)
 
 	//Eileen Liu
	//June 01, 2010
 
   import javax.swing.*; //the ImageIcon Class
   import java.awt.*; //the Image Class
	/**
    * A type of list node that stores the image of a costume. It is used to create circular doubly linked lists of costume images.
	 * @author  Eileen Liu
 	 */

    public class CostumeNode implements Comparable<CostumeNode>
   {
      /**The filename of the costume.*/
		private String myFilename; 
		/**The image of the costume.*/
      private ImageIcon myImage; 
		/**The next costume.*/
      private CostumeNode myNext;
		/**The previous costume.*/
		private CostumeNode myPrev;
		/**The costume's priority, which determines what layer order the costume goes on.*/
      private int myPriority;
  		/**The gender the costume is for.*/    
		private String myGender; //the gender the costume is for 
     	  /** 
   	  	* Constructs a CostumeNode for storing images of costumes
         * @param filename the filename of the image
   		* @param p the priority of the CostumeNode
   		*/
       public CostumeNode(String filename, int p, String details)
      {
         myFilename=filename;
         myImage = null;
         myNext=null;
         myPrev=null;    
         myPriority=p;
			//determines the gender the costume is for
			if(details.contains("Male"))
            myGender= "Male";
         else if(details.contains("Female"))
            myGender= "Female";
         else
            myGender= "Unisex";
      }
        /**
   	   * Constructs a CostumeNode for storing images of costumes
         * @param filename the filename of the image
   		* @param p the priority of the CostumeNode
   		* @param prev the previous CostumeNode it is linked to
   		* @param next the next CostumeNode it is linked to
   		*/
   
       public CostumeNode(CostumeNode prev, String filename, int p, CostumeNode next, String details)
      {
         myImage = null;
         myPrev = prev;      
         myNext = next;
         myPriority=p;
			//determines the gender the costume is for
         if(details.contains("Male"))
            myGender= "Male";
         else if(details.contains("Female"))
            myGender= "Female";
         else
            myGender= "Unisex";
      }
		/**
     * Compares this CostumeNode to the specified CostumeNode. Implemented so that CostumeNode may be stored in a priority queue.
     * @param     other		the CostumeNode this one is being compared with
     * @return    the diffence of this CostumeNode's priority and the other's
     */
       public int compareTo(CostumeNode other)//compares this costume node to the other
      {
         return myPriority - other.myPriority; //returns the difference of this costume node and the other
      }
   	//accessor methods
       
	 /**
     * Returns the name of the costume by formatting the filename of the costume.
     * @return    the name of the costume
     */
		 public String toString()
      {
         String name ="";
         if(myFilename.contains("/")&&myFilename.contains("(")) //checks if filename is in another folder and specifies gender in parenthesis
            name=myFilename.substring(myFilename.lastIndexOf("/")+1, myFilename.indexOf("(")); //uese filename without folders, genderspecification, and extension as costume name
         else if(myFilename.contains("/"))//checks if filename is in another folder
            name=myFilename.substring(myFilename.lastIndexOf("/")+1, myFilename.indexOf("."));//uses filename without folders and extension as the costume name
         else if(myFilename.contains("(")) //checks if filename specifies gender in parenthesis
            name=myFilename.substring(0, myFilename.indexOf("(")); //uese filename genderspecification and extension as costume name
         else
            name=myFilename.substring(0, myFilename.indexOf(".")); //simply uses filename without extension as the costume name
         return name; //returns the name of the costume
      }
		/** Returns the filename of the costume image*/
       public String getFile()
      {
         return myFilename;
      }
		/** Returns the priority of the costume*/
       public Integer getPriority()
      {
         return myPriority;
      }
		/** Returns which gender the costume is for*/
       public String getGender() 
      {
         return myGender;
      }
		/** Returns the image of the costume*/
		 public Image getImage()
      {
         if(myImage==null) //checks if the image needs to be extracted from the filename
         {
            ImageIcon img = new ImageIcon(myFilename); //creates an ImageIcon from the filename
            return img.getImage(); //returns the image extracted from the ImageIcon
         }
         else //otherwise the image can be returned more directly
         {
            Image temp = myImage.getImage(); 
           // myImage=null;   //resets myImage to null, to avoid running into the OutOfMemoryError that occurs if too many images are stored permanately
            return temp;   //returns the image of the costume
         }
      }
		public void resetImage()
		{
		myImage=null;
		}
		/** Returns the next CostumeNode*/
       public CostumeNode getNext()
      {
   		myImage=null;      
			return myNext;//returns the CostumeNode's next
      }
		/** Returns the previous CostumeNode*/
       public CostumeNode getPrev()
      {
   		myImage=null;      
			return myPrev ;//returns the CostumeNode's previous
      }
      //modifier methods	
      /**Sets the gender of the costume to the specified gender*/
       public void setGender(String gender)
      {
         myGender=gender;
         myFilename=""+getFile().substring(0, getFile().indexOf("(")+1)+gender+getFile().substring(getFile().indexOf(")"));
      }
		/**Sets the costume image to the image at the specified filename*/
       public void setImage(String filename)
      {
         myFilename=filename;
      }
		/** Sets the costume image to the specified image*/
       public void setImage(Image img)
      {
         myImage = new ImageIcon(img);
      }
		/** Sets the next CostumeNode to the specified CostumeNode*/
       public void setNext(CostumeNode cn)
      {
         myNext = cn;
      }
		/** Sets the previous CostumeNode to the specified CostumeNode*/
       public void setPrev(CostumeNode cn)
      {
         myPrev  = cn;
      }
       
      
   }