 //APCS DATA STRUCTURES are used this class (Priority Queues, Circular Doubly Linked Lists, and list nodes)
   
	//Eileen Liu
   //June 01, 2010
   import javax.swing.*; //the JPanel Class
   import java.awt.*; //the Image class, the Graphics Class, the Color Class
   import java.util.*; //the PriorityQueue class, the Scanner class
   import java.io.*; //the FileNotFoundException, the File class
   import java.awt.image.FilteredImageSource; /*(Description from Java's API) the FilteredImageSource 
	//Class, an implementation of the ImageProducer interface which takes an existing image and a filter
	//object and uses them to produce image data for a new filtered version of the original image*/
   import java.awt.image.RGBImageFilter;/*(Description from Java's API) This class provides an easy way 
	//to create an ImageFilter which modifies the pixels of an image in the default RGB ColorModel. 
	//It is meant to be used in conjunction with a FilteredImageSource object to produce filtered 
	//versions of existing images. It is an abstract class that provides the calls needed to channel 
	//all of the pixel data through a single method which converts pixels one at a time in the default 
	//RGB ColorModel regardless of the ColorModel being used by the ImageProducer. The only method which 
	//needs to be defined to create a useable image filter is the filterRGB method.*/
   import java.awt.image.ImageFilter;/*(Description from Java's API) This class implements a filter 
	//for the set of interface methods that are used to deliver data from an ImageProducer to an ImageConsumer. 
	//It is meant to be used in conjunction with a FilteredImageSource object to produce filtered versions of 
	//existing images. It is a base class that provides the calls needed to implement a "Null filter" which has 
	//no effect on the data being passed through. Filters should subclass this class and override the methods 
	//which deal with the data that needs to be filtered and modify it as necessary*/ 
	
	/**
 	 * DisplayPanel displays the character and costumes, it changes costumes based on buttons pressed in the ButtonPanel. 
	 * @author  Eileen Liu
	 * @see     javax.swing.JPanel
    */
	 
   public class DisplayPanel extends JPanel 
   {
   	/** The main panel containing the display panel.*/
      private MasqPanel parentPanel;
      /***True if the color of a costume has been changed recently, false by default*/
      //public boolean hasColorChanged = false; 
      /**The image of the original uncolored costume (if color of a costume has been changed).*/
      //public Image untintedImg; 
      /**The Costume that was changed most recently.*/
      public CostumeNode lastChanged; 
      private CostumeNode myHair; //points to the current Hairstyle costume item
      private CostumeNode myEyewear; //points to the current Eyewear costume item
      private CostumeNode myEyes; //points to the current style of Eyes costume item
      private CostumeNode myNose; //points to the current style of Nose costume item
      private CostumeNode myMouth; //points to the current sytle of Mouth costume item
      private CostumeNode myAccessoryOne; //points to the current Accessory 1 costume item
      private CostumeNode myAccessoryTwo; //points to the current Acessory 2 costume item
      private CostumeNode myTop; //points to the current Top costume item
      private CostumeNode myBottom; //points to the current Bottom costume item
      private CostumeNode myShoes; //points to the current Shoes costume item
      private CostumeNode myBackground; //points to the current Background costume item
      private CostumeNode myBase; //points to the current character Base costume item (Male or Female)
      /**The x coordinate the costume images are drawn from.*/
      private int STARTX; 
   	/**The y coordinate the costume images are drawn from.*/
      private int STARTY; 
      /**The height of the costume images being displayed.*/
      private int IMAGEHEIGHT; 
   	/**The width of the costume images being displayed.*/
      private int IMAGEWIDTH; 
       
   	 /**
        * Constructs DisplayPanel and creates wardrobe of costumes.
   	  * @param     m	the MasqPanel that contains this DisplayPanel.
        */
      public DisplayPanel(MasqPanel m)
      {
         parentPanel=m; //links this DisplayPanel to the MasqPanel that contains it
         try 
         {
            createwardrobe();
         }
            catch(FileNotFoundException e)//At least one necessary file is missing
            {
               System.out.println("One or more files were not found"); //prints error message
               System.exit(0);
            }
      }
     	   /**
   		 * Creates a circular doubly linked list of CostumeNodes for each type of costume.
   		 */
      private void createwardrobe()throws FileNotFoundException
      {
         myBackground = createCostumeList("BackgroundList.txt");//new CostumeNode("Sky.jpg", getPriority("Background"), "");
         myBase = createCostumeList("BaseList.txt");
         myShoes = createCostumeList("ShoesList.txt");
         myBottom= createCostumeList("BottomList.txt");
         myTop=createCostumeList("TopList.txt"); //Creates a CIRCULAR DOUBLY LINKED LIST of costume tops from the textfile
         myMouth=createCostumeList("MouthList.txt");
         myNose=createCostumeList("NoseList.txt");
         myEyes=createCostumeList("EyesList.txt");
         myEyewear=createCostumeList("EyewearList.txt");		
         myHair=createCostumeList("HairstyleList.txt");
         myAccessoryOne=createCostumeList("AccessoriesList.txt");
         myAccessoryTwo=createCostumeList("AccessoriesList.txt");
         lastChanged = myTop; //sets lastChanged to myTop by default (to prevent errors if the user 
      	//tries to change color without first changing a costume)	
      }
   	/**
   	* Calculates the dimensions and coordinates of the character based off of the panel size then paints the display.
   	* @see	javax.swing.JComponent#paintComponent(java.awt.Graphics)
   	*/
      public void paintComponent(Graphics g)
      {
         IMAGEWIDTH = (int)(this.getSize().getWidth()*9.0/10.0); //calculates the width of the images being displayed
         IMAGEHEIGHT= (int)(this.getSize().getHeight()*9.0/10.0);
         STARTX=(int)(this.getSize().getWidth()-IMAGEWIDTH)/2;
         STARTY=(int)(this.getSize().getHeight()-IMAGEHEIGHT)/2;
      
         update(g);
      }
      //APCS DATA STRUCTURES are used in the method below (Priority Queue)
   	/**
   	 * Updates the display using a priority queue to determine order the costumes are drawn. 
   	 * @see	javax.swing.JComponent#update(java.awt.Graphics)
   	 */
      public void update(Graphics g)//overrides update method to prevent continuous uneccessary repainting
      {
         //checks if gender of the costume top and the gender of the base match
         if(myTop.getGender().equals("Male")&&myBase.getGender().equals("Female")) //if the base is female and the costume top is for males
            myTop.setGender("Female"); //puts on the female vesion of the costume
         else if(myTop.getGender().equals("Female")&&myBase.getGender().equals("Male")) //if the base is male and the costume top is for females
            myTop.setGender("Male"); //puts on the male version of the costume
         PriorityQueue<CostumeNode> pq = new PriorityQueue<CostumeNode>();
         //adds all CostumeNodes (myHair, myTop...etc) to a priority queue
         pq.add(myAccessoryOne);
         pq.add(myAccessoryTwo);
         pq.add(myHair);
         pq.add(myEyewear);
         pq.add(myEyes);
         pq.add(myNose);
         pq.add(myMouth);      
         pq.add(myTop);
         pq.add(myBottom);
         pq.add(myShoes);
         pq.add(myBase);
         pq.add(myBackground);
      	//draws each costume in the order it is removed from the priority queue
      	//this prevents costumes from being drawn in the wrong order, which would ruin things
      	//(for example, painting the background last would cover up everything else, which is a problem)  
         while(pq.size()>0)
         { 
            CostumeNode cn = pq.remove();
            if(!cn.equals(myBackground))
               //g.drawImage(cn.getImage(), 0, 0, 510, 655, null);
               g.drawImage(cn.getImage(), STARTX, STARTY, IMAGEWIDTH, IMAGEHEIGHT, null);
            else
               g.drawImage(cn.getImage(), 0, 0, (int)this.getSize().getWidth(), (int)this.getSize().getHeight(), null);     
         }  
      }
    /**
     * Changes costumes depending on which button was pressed.
     *
     * @param     r	the row of the button pressed.
     * @param     c	the column of the button pressed.
     */
   //      Background<Base<Shoes<Bottom<Top<Mouth<Nose<Eyes<Eyewear<Hair<Accessory
      public void changeCostume(int r, int c)
      {
         //concludes which costume to change (Top, Bottom, Shoes...etc. ?) based on the row of the button pressed
         //concludes which costume to change to (next or previous?) based on the column of the button pressed
         if(r==0)//myHair
         {
            if(c==0)	//previous
               myHair=myHair.getPrev();
            else	//next
               myHair=myHair.getNext();
            parentPanel.buttons.updateCostumeLabel(r, myHair.toString());
            lastChanged=myHair;
         }
         
         else if(r==1)//myEyewear
         {
            if(c==0)	//previous
               myEyewear=myEyewear.getPrev();
            else	//next
               myEyewear=myEyewear.getNext();
            parentPanel.buttons.updateCostumeLabel(r, myEyewear.toString());
            lastChanged=myEyewear;
         }
         else if(r==2)//myEyes
         {
            if(c==0)	//previous
               myEyes=myEyes.getPrev();
            else	//next
               myEyes=myEyes.getNext();
            parentPanel.buttons.updateCostumeLabel(r, myEyes.toString());
            lastChanged=myEyes;
         }
         else if(r==3)//myNose
         {
            if(c==0)	//previous
               myNose=myNose.getPrev();
            else	//next
               myNose=myNose.getNext();
            parentPanel.buttons.updateCostumeLabel(r, myNose.toString());
            lastChanged=myNose;
         }
         else if(r==4)//myMouth
         {
            if(c==0)	//previous
               myMouth=myMouth.getPrev();
            else	//next
               myMouth=myMouth.getNext();
            parentPanel.buttons.updateCostumeLabel(r, myMouth.toString());
            lastChanged=myMouth;
         }
         else if(r==5)//myAccessoryOne
         {
            if(c==0)	//previous
               myAccessoryOne=myAccessoryOne.getPrev();
            else	//next
               myAccessoryOne=myAccessoryOne.getNext();
            parentPanel.buttons.updateCostumeLabel(r, myAccessoryOne.toString());
            lastChanged=myAccessoryOne;
         }
         else if(r==6)//myAccessoryTwo
         {
            if(c==0)	//previous
               myAccessoryTwo=myAccessoryTwo.getPrev();
            else	//next
               myAccessoryTwo=myAccessoryTwo.getNext();
            parentPanel.buttons.updateCostumeLabel(r, myAccessoryTwo.toString());
            lastChanged=myAccessoryTwo;
         }
         else if(r==7)//myTop
         {
            if(c==0)	//previous
               myTop=myTop.getPrev();
            else	//next
               myTop=myTop.getNext();
            lastChanged=myTop;
            parentPanel.buttons.updateCostumeLabel(r, myTop.toString());
         }
         
         else if(r==8)//myBottom
         {
            if(c==0)	//previous
               myBottom=myBottom.getPrev();
            else	//next
               myBottom=myBottom.getNext();
            parentPanel.buttons.updateCostumeLabel(r, myBottom.toString());
            lastChanged=myBottom;
         }
         else if(r==9)//myShoes
         {
            if(c==0)	//previous
               myShoes=myShoes.getPrev();
            else	//next
               myShoes=myShoes.getNext();
            parentPanel.buttons.updateCostumeLabel(r, myShoes.toString());
            lastChanged=myShoes;
         }
         else if(r==10)//myBase
         {
            if(c==0)	//previous
               myBase=myBase.getPrev();
            else	//next
               myBase=myBase.getNext();
            parentPanel.buttons.updateCostumeLabel(r, myBase.toString());
            lastChanged=myBase;
         }
         else if(r==11)//myBackground
         {
            if(c==0)	//previous
               myBackground=myBackground.getPrev();
            else	//next
               myBackground=myBackground.getNext();
            parentPanel.buttons.updateCostumeLabel(r, myBackground.toString());
            lastChanged=myBackground;
         }  
         repaint();
      }
    /**
     * Returns a circular doubly linked list of CostumeNodes created from the specifed textfile.
     *
     * @param     textfile  the filename containing the filenames of images used to create CostumeNodes.
     * @return    the first CostumeNode in the circular doubly linked list of CostumeNodes.
     * @exception FileNotFoundException		if the file cannot be found.
     */
      private CostumeNode createCostumeList(String textfile)throws FileNotFoundException
      {
         Scanner infile = new Scanner(new File(textfile)); //creates a scanner that reads from the textfile
         CostumeNode head=null; 
         //creates the first CostumeNode in the list
         if(infile.hasNextLine())
         {
            String firstline = infile.nextLine(); //stores the first line
            String firstImageFile = firstline.substring(0, firstline.indexOf(" ")); //extracts the name of the first imagefile from the first line
            String details = firstline.substring(firstline.indexOf(" ")+1); //extracts the details of the costume from the first line
            head=new CostumeNode(firstImageFile, getPriority(details), details); //creates the first costume in the list from the extracted information
         }      
         CostumeNode current = head;
         //links each costume into a DOUBLY LINKED LIST
         while(infile.hasNextLine())
         {
            String line = infile.nextLine(); //stores next line scanned by the scanner
            String imageFile = line.substring(0, line.indexOf(" ")); //extracts the name of the imagefile from the line
            String details = line.substring(line.indexOf(" ")+1); //extracts the details of the costume from the line
            CostumeNode cn=new CostumeNode(imageFile, getPriority(details), details);//Creates next costume from the extracted information
            current.setNext(cn); //links the current costume to the next one in the list
            cn.setPrev(current); //links the next costume to the current one
            current=current.getNext(); //updates which costume is the current one, continues down the list
         }
         //links the back of the list to the front (makes it a CIRCULAR DOUBLY LINKED LIST)
         if(head!=null&&!head.equals(current)) //checks if the list isn't empty or with only one costume
         {
            head.setPrev(current); //links the first costume to the last
            current.setNext(head); //links the last costume to the first
         }
         return head;  //returns first costume node in the circular doubly linked list
      }
   	 
    /** 
     * Returns priority determined from the specifed string.
     * @param     s  the String used to determine priority, contains details about about the type and gender (if specified) of a costume.
     * @return    the priority of a costume.
     */
      private int getPriority(String s)
      {
         if(s.contains("Male")||s.contains("Female")) //check if gender is specified in string s
         {
            s=s.substring(s.indexOf(" ")+1); //removes it, since it is extra information
         }
      // Default order of priority: Background<Base<Shoes<Bottom<Top<Mouth<Nose<Eyes<Eyewear<Hair<Accessory
      //(There are some exceptions)
         if(s.equals("Accessory"))
            return 10;
         else if(s.equals("Hair"))
            return 9;
         else if(s.equals("Eyewear"))
            return 8;
         else if(s.equals("Eyes"))
            return 7;
         else if(s.equals("Nose"))
            return 6;
         else if(s.equals("Mouth"))
            return 5;
         else if(s.equals("Top"))
            return 4;
         else if(s.equals("Bottom"))
            return 3;
         else if(s.equals("Shoes"))
            return 2;
         else if(s.equals("Base"))
            return 1;
         else if(s.equals("Background"))
            return 0;
         else //the priority is an exception and must already be specified by an integer
         {
            int priority;
            try 
            {
               priority = Integer.parseInt(s);
            }
               catch(NumberFormatException k)//s is not an integer
               {
                  priority=-1;
               }
            return priority;
         }
      }
    /** 
     * Changes the color of the specified costume to the specified color and returns the image of the original uncolored costume.
     * @param     cl  the Color to change the costume to.
     * @param     costume		the costume to change the color of.
     * @return    the original image of the costume before the color was changed.
     */
      public void changeColor(Color cl, CostumeNode costume)//
      {
         costume.resetImage();
         Image untinted = costume.getImage(); //stores the orignal image of the costume
         ImageFilter colorfilter = new TintFilter(cl); //creates a ImageFilter that will filter an image to the specified color
         Image img = createImage(new FilteredImageSource(costume.getImage().getSource(), colorfilter)); //creates the colored changed version of the costume image
         costume.setImage(img); //sets the costume's image to the color changed version
         repaint();
      }
   	
    /**
     * An image filter class that tints colors based on the tint provided to the
     * constructor (the color of an object). Taken from GridWorld Case Study\GridWorldCode\framework\info\gridworld\gui\ImageDisplay.java
     * http://apcentral.collegeboard.com/apc/public/repository/GridWorldCode.zip
	  * which is modified under "the terms of the GNU General Public License as published by the Free Software Foundation".
     */
	  
      private static class TintFilter extends RGBImageFilter
      {
         private int tintR, tintG, tintB;
      
        /**
         * Constructs an image filter for tinting colors in an image.
         * @param color the tint color
         */
         public TintFilter(Color color)
         {
            canFilterIndexColorModel = true;
            int rgb = color.getRGB();
            tintR = (rgb >> 16) & 0xff;
            tintG = (rgb >> 8) & 0xff;
            tintB = rgb & 0xff;
         }
      
         public int filterRGB(int x, int y, int argb)
         {
            // Separate pixel into its RGB coomponents.
            int alpha = (argb >> 24) & 0xff;
            int red = (argb >> 16) & 0xff;
            int green = (argb >> 8) & 0xff;
            int blue = argb & 0xff;
            // Use NTSC/PAL algorithm to convert RGB to gray level
            double lum = (0.2989 * red + 0.5866 * green + 0.1144 * blue) / 255;
         
            // interpolate between tint and pixel color. Pixels with
            // gray level 0.5 are colored with the tint color,
            // white and black pixels stay unchanged.
            // We use a quadratic interpolation function
            // f(x) = 1 - 4 * (x - 0.5)^2 that has
            // the property f(0) = f(1) = 0, f(0.5) = 1
            
            // Note: Julie's algorithm used a linear interpolation
            // function f(x) = min(2 - 2 * x, 2 * x);
            // and it interpolated between tint and 
            // (lum < 0.5 ? black : white)
         
            double scale = 1 - (4 * ((lum - 0.5) * (lum - 0.5)));
            
            red = (int) (tintR * scale + red * (1 - scale));
            green = (int) (tintG * scale + green * (1 - scale));
            blue = (int) (tintB * scale + blue * (1 - scale));
            return (alpha << 24) | (red << 16) | (green << 8) | blue;
         }
      }
   }