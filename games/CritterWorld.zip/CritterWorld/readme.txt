Double click CritterWorld.jar to run.
Left click to select a hexagon.
Right click to view dropdown of all possible actions at the hexagon.
In bottom right panel you can set world to run in timesteps, select random for critters to act on their own (you must place them first however).

World.txt is a sample importable world.
critter1.txt and critter2.txt are sample importable critters.
You may create your own importable worlds/critters by making a text file in the same format.